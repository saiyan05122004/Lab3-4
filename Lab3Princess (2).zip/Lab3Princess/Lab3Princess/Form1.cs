﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab3Princess
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private Princess princess1;
        private Princess princess2;

        private void Form1_Load(object sender, EventArgs e)
        {
            // создаем объекты принцесс с помощью конструктора с двумя аргументами
            princess1 = new Princess("Алиса", 50);
            princess2 = new Princess("Белль", 60);

            // выводим имя каждой принцессы в соответствующей метке
            lblPrincess1Name.Text = princess1.Name;
            lblPrincess2Name.Text = princess2.Name;

            // выводим текущий вес каждой принцессы в соответствующей метке
            lblPrincess1Change.Text = $"{princess1.Weight} кг";
            lblPrincess2Change.Text = $"{princess2.Weight} кг";
        }





        private void btnChangeWeight_Click_1(object sender, EventArgs e)
        {
            // получаем новый вес каждой принцессы из соответствующих текстовых полей
            double newWeight1 = double.Parse(txtPrincess1Weight.Text);
            double newWeight2 = double.Parse(txtPrincess2Weight.Text);

            // изменяем вес каждой принцессы на разницу между текущим и новым весом
            double delta1 = newWeight1 - princess1.Weight;
            princess1.ChangeWeight(delta1);

            double delta2 = newWeight2 - princess2.Weight;
            princess2.ChangeWeight(delta2);

            // выводим сообщения об изменении веса для каждой принцессы
            MessageBox.Show($"Принцесса {princess1.Name} изменила свой вес на {delta1:F2} кг!");
            MessageBox.Show($"Принцесса {princess2.Name} изменила свой вес на {delta2:F2} кг!");

            // выводим новый вес каждой принцессы
            lblPrincess1Change.Text = $"{princess1.Weight} кг";
            lblPrincess2Change.Text = $"{princess2.Weight} кг";
        }

        private void btnCalculateAvgWeight_Click_1(object sender, EventArgs e)
        {
            // считываем вес каждой принцессы из текстовых полей
            double weight1 = double.Parse(txtPrincess1Weight.Text);
            double weight2 = double.Parse(txtPrincess2Weight.Text);

            // считаем средний вес
            double averageWeight = (weight1 + weight2) / 2;

            // выводим средний вес в метку lblAverage
            MessageBox.Show($"Средний вес: {averageWeight} кг");
        }

        private void lblPrincess1Change_Click(object sender, EventArgs e)
        {

        }
    }
}
