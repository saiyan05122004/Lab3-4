﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3Princess
{
    public class Princess
    {
        public string Name { get; set; }
        public double Weight { get; set; }

        public Princess(string name, double weight)
        {
            this.Name = name;
            this.Weight = weight;
        }

        // метод для изменения веса принцессы на заданную величину
        public void ChangeWeight(double delta)
        {
            this.Weight += delta;
        }
    }


}
